package com.smhrd.controller;

import java.io.IOException;
import java.io.Writer;
import java.lang.ProcessBuilder.Redirect;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.websocket.SendResult;

import com.mysql.cj.Session;


@WebServlet("/TestLoginCheck")
public class TestLoginCheck extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		HttpSession session = request.getSession();
		System.out.println(id);
		System.out.println(pw);
		if(id.equals("smart")&&pw.equals("12345")) {
			session.setAttribute("id", id);
			response.sendRedirect("TestMain.jsp");
		}else {
			response.sendRedirect("TestLoginForm.html");
		}
		
		
	}

}
