package com.smhrd.database;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.smhrd.model.MemberVO;
import com.smhrd.model.MemberVOtest;

public class DAO {

	// Data Access Object
	// 데이터에 접근하는 객체

	// 1. 필드
	// DBCP 꺼내오기

	private SqlSessionFactory factory = MySqlSessionManager.getSqlSessionFactory();
		
	public int join(MemberVO vo) {

		// 1. 연결객체 빌려오기
		SqlSession session = factory.openSession(true);

		// 2. 연결객체 사용하기
		// *공통*
		// 매개변수 한개 >> Mapper파일의 sql 구문 id값
		// 매개변수 두개 >> id값, 보내줘야하는 데이터
		// session.insert() : insert 구문
		// session.delete() : delete 구문
		// session.update() : update 구문
		// session.selectOne() : select 구문 데이터 한개
		// session.selectList() : select 구문 데이터 여러개
		int row = session.insert("join", vo);
		// MemberMapper에서 설정한 "join"

		// 3. 연결객체 반납하기
		session.close();
		// 4. 결과 값 반환
		return row;
	}
		
	public MemberVO login(MemberVO vo) {
		// 연결객체 빌려오기
		SqlSession session = factory.openSession();
		// 연결객체 사용하기 >> select >> 데이터 한개
		// --> select 기능을 수행하고 난 결과 자료형은 제네릭 기법으로 결정된다.
		// 제네릭 기법이란?
		// : 클래스 내부(sqlSession)에서 사용해야하는 자료형을 클래스 외부(DAO)에서 결정하는 기법
		MemberVO resultVO = session.selectOne("login", vo);
		// 연결객체 반납하기
		session.close();
		// 결과 값 반환
		return resultVO;
	}
		
	public List<MemberVO> selectAll() {
		// 연결객체 빌려오기
		SqlSession session = factory.openSession(true);
		// 연결객체 사용하기
		List<MemberVO> resultList = session.selectList("selectAll");
		// MemberVO --> 회원 1명에 대한 정보
		// 우리가 필요한건 ? 회원 여러명에 대한 정보 --> 몇명일지 알 수 없다.
		// MemberVO 하나로 묶어서 표현하는 자료구조 중에 가변적인 ? >> ArrayList >> List
		// List란?
		// --> ArrayList의 상위 클래스
		// --> 더 추상적인 클래스
		// ** Collection 구조 **
		// 연결객체 반납
		session.close();
		// 결과값 반환
		return resultList;
	}

	public void update(MemberVO vo) {
		// 연결 객체
		SqlSession session = factory.openSession(true);
		// 연결객체 사용하기
		session.update("update", vo);
		// 연결객체 반납
		session.close();
		// 결과값 반환
		
	}
	
	public List<MemberVOtest> todoList() {
		// 연결객체 빌려오기
		SqlSession session = factory.openSession();
		// 연결객체 사용하기
		List<MemberVOtest> todoList = session.selectList("todoList");
		// 연결객체 반납
		session.close();
		// 결과값 반환
		return todoList;
		
	}

	public void todoDel(MemberVOtest vo) {
		// 연결객체 빌려오기
		SqlSession session = factory.openSession(true);
		// 연결객체 사용하기
		session.delete("todoDel",vo);
		// 세션 닫기
		session.close();		
	}
	public void todoMove(MemberVOtest vo) {
		// 연결객체 빌려오기
		SqlSession session = factory.openSession(true);
		// 연결객체 사용하기
		session.update("todoMove",vo);
		// 세션 닫기
	}
	
	public String EmailCheck(String email) {
		// 1. 세션 빌려오기
		SqlSession session = factory.openSession(true);
		// 2. 세션 사용하기 -> select 구문 데이터 한개만 조회
		String result = session.selectOne("EmailCheck", email);
		// 3. 세션 반납하기
		session.close();
		// 4. 결과창 확인하기
		return result;
		
		
		
		
	}

}
