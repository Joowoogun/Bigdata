package com.smhrd.model;

public class MemberVOtest {
	
	// test1 필드
		private String nick;
		private String textval;
		private String stat;
	
	// 생성자 메소드
		public MemberVOtest() {
			
		}
		
		public MemberVOtest(String textval, String stat) {	
			this.textval = textval;
		}
		
	// 게터 세터	
		public String getNick() {
			return nick;
		}

		public void setNick(String nick) {
			this.nick = nick;
		}

		public String getStat() {
			return stat;
		}

		public void setStat(String stat) {
			this.stat = stat;
		}

			
		public String getTextval() {
			return textval;
		}

		public void setTextval(String memo) {
			this.textval = memo;
		}

}
