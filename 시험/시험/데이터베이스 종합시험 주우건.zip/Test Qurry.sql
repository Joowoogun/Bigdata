-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema haksk
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema datatest
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema datatest
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `datatest` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
USE `datatest` ;

-- -----------------------------------------------------
-- Table `datatest`.`t_cus`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `datatest`.`t_cus` (
  `id` INT NOT NULL,
  `customer_name` VARCHAR(45) NOT NULL,
  `customer_adress` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `datatest`.`t_order`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `datatest`.`t_order` (
  `order_number` INT NOT NULL,
  `order_name` VARCHAR(50) NULL,
  `order_count` INT NULL,
  `order_price` INT NULL,
  `id` INT NOT NULL,
  PRIMARY KEY (`order_number`),
  INDEX `fk_t_order_t_cus_idx` (`id` ASC) VISIBLE,
  CONSTRAINT `fk_t_order_t_cus`
    FOREIGN KEY (`id`)
    REFERENCES `datatest`.`t_cus` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;



INSERT INTO t_cus (id, customer_name, customer_adress)
VALUES
('001', '가길동', '수원시'),
('002', '나길동', '안산시'),
('003', '조길동', '서울시'),
('004', '홍길동', '안양시');

INSERT INTO t_order (order_number, order_name, order_count, order_price, id )
VALUES
('101', '사과', '2', '300','001'),
('102', '우유', '3', '200','001'),
('103', '시금치', '4', '100','002'),
('104', '콜라', '7', '200','002'),
('105', '두부', '5', '300','003'),
('106', '햄버거', '2', '200','003'),
('107', '빵', '3', '100','003'),
('108', '감자', '1', '200','003'),
('109', '오이', '5', '200','004');

select customer_name, customer_adress, order_name, order_count, order_price
from t_order o
inner join t_cus c
on o.id=c.id;
